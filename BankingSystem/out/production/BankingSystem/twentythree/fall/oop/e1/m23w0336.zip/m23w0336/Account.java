package twentythree.fall.oop.e1.m23w0336;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Scanner;

public class Account {
    public static void addAccount(JSONArray accounts) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter account details:");
        System.out.print("Name: ");
        String name = scanner.next();

        System.out.print("Balance: ");
        double balance = scanner.nextDouble();

        JSONObject newAccount = new JSONObject();
        newAccount.put("name", name);
        newAccount.put("balance", balance);

        accounts.put(newAccount);

        System.out.println("Account added successfully.");
    }

}
