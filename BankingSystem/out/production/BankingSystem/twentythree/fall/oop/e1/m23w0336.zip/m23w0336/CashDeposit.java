package twentythree.fall.oop.e1.m23w0336;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Scanner;

public class CashDeposit {
    public static void deposit(JSONArray accounts) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter account number to deposit into: ");
        int accountNumber = scanner.nextInt();

        if (accountNumber >= 1 && accountNumber <= accounts.length()) {
            JSONObject account = accounts.getJSONObject(accountNumber - 1);

            System.out.print("Enter amount to deposit: ");
            double amount = scanner.nextDouble();

            double currentBalance = account.getDouble("balance");
            account.put("balance", currentBalance + amount);

            System.out.println("Deposit successful. Updated balance: " + account.getDouble("balance"));
        } else {
            System.out.println("Invalid account number.");
        }
    }
}
