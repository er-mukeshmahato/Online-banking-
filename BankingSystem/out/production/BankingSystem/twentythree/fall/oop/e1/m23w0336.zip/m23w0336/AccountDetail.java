package twentythree.fall.oop.e1.m23w0336;

import org.json.JSONArray;
import org.json.JSONObject;

public class AccountDetail {


    public static void displayAccounts(JSONArray accounts) {
        System.out.println("Accounts:");
        for (int i = 0; i < accounts.length(); i++) {
            JSONObject account = accounts.getJSONObject(i);
            System.out.println("Account " + (i + 1) + ": " + account.toString());
        }
    }
}
