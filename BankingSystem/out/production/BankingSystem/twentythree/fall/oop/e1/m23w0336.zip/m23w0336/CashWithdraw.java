package twentythree.fall.oop.e1.m23w0336;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Scanner;

public class CashWithdraw {
    public static void withdraw(JSONArray accounts) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter account number to withdraw from: ");
        int accountNumber = scanner.nextInt();

        if (accountNumber >= 1 && accountNumber <= accounts.length()) {
            JSONObject account = accounts.getJSONObject(accountNumber - 1);

            System.out.print("Enter amount to withdraw: ");
            double amount = scanner.nextDouble();

            double currentBalance = account.getDouble("balance");
            if (currentBalance >= amount) {
                account.put("balance", currentBalance - amount);
                System.out.println("Withdrawal successful. Updated balance: " + account.getDouble("balance"));
            } else {
                System.out.println("Insufficient funds.");
            }
        } else {
            System.out.println("Invalid account number.");
        }
    }
}
