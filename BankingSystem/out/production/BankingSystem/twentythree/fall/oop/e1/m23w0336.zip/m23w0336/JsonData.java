package twentythree.fall.oop.e1.m23w0336;

import org.json.JSONArray;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class JsonData {
    private static final String JSON_FILE_PATH = "accounts.json";
    public static JSONArray loadAccounts() {
        try {
            String jsonContent = new String(Files.readAllBytes(Paths.get(JSON_FILE_PATH)));
            return new JSONArray(jsonContent);
        } catch (IOException e) {
            System.out.println("Error reading JSON file. Creating a new one.");
            return new JSONArray();
        }
    }
    public static void saveAccounts(JSONArray accounts) {
        try (FileWriter fileWriter = new FileWriter(JSON_FILE_PATH)) {
            fileWriter.write(accounts.toString(2));
            System.out.println("Accounts saved to " + JSON_FILE_PATH);
        } catch (IOException e) {
            System.out.println("Error saving accounts to JSON file.");
            e.printStackTrace();
        }
    }
}
