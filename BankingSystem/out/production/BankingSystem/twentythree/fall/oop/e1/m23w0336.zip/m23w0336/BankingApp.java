package twentythree.fall.oop.e1.m23w0336;

/*
 * Author Name:Mukesh kumar Mahato
 * Student ID:M23W0336
 * Class :OOP
 * Assignment: Final Project
 *
 */

import org.json.JSONArray;
import java.util.Scanner;

public class BankingApp {



    public static void main(String[] args) {
        // Load existing account data from JSON file
        JsonData Jdata=new JsonData();
        JSONArray accounts = Jdata.loadAccounts();

        // Run the banking app
        runBankingApp(accounts);

        // Save updated account data to the JSON file
        Jdata.saveAccounts(accounts);
    }



    private static void runBankingApp(JSONArray accounts) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Banking App Menu:");
            System.out.println("1. Display Accounts");
            System.out.println("2. Add Account");
            System.out.println("3. Withdraw");
            System.out.println("4. Deposit");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    AccountDetail ADetail=new AccountDetail();
                    ADetail.displayAccounts(accounts);
                    break;
                case 2:
                    Account Acc=new Account();
                    Acc.addAccount(accounts);
                    break;
                case 3:
                    CashWithdraw wDraw=new CashWithdraw();
                    wDraw.withdraw(accounts);
                    break;
                case 4:
                    CashDeposit CDeposit=new CashDeposit();
                    CDeposit.deposit(accounts);
                    break;
                case 5:
                    System.out.println("Exiting the Banking App. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

}
